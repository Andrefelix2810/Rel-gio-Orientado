document.addEventListener('DOMContentLoaded', function () {
    function getHoraAtual() {
        return new Date();
    }

    function atualizarTempo() {
        var agora = getHoraAtual();
        var horas = agora.getHours();
        var minutos = agora.getMinutes();
        var segundos = agora.getSeconds();

        document.getElementById('horas').textContent = horas < 10 ? '0' + horas : horas;
        document.getElementById('minutos').textContent = minutos < 10 ? '0' + minutos : minutos;
        document.getElementById('segundos').textContent = segundos < 10 ? '0' + segundos : segundos;
    }

    function definirGifEGradiente() {
        atualizarTempo();

        var horas = getHoraAtual().getHours();
        var gifElement = document.getElementById('gif');
        var bodyElement = document.body;

        if (horas >= 6 && horas < 12) {
            gifElement.src = 'img/manha.gif';
            bodyElement.style.background = 'linear-gradient(-120deg, #66c0ff, #000000)';
        } else if (horas >= 12 && horas < 15) {
            gifElement.src = 'img/meiodia.gif';
            bodyElement.style.background = 'linear-gradient(-120deg, #ffcc66, #000000)';
        } else if (horas >= 15 && horas < 18) {
            gifElement.src = 'img/tarde.gif';
            bodyElement.style.background = 'linear-gradient(-120deg, #ffaa80, #000000)';
        } else if ((horas >= 18 && horas <= 23) || (horas >= 0 && horas < 6)) {
            gifElement.src = 'img/img prova.gif';
            bodyElement.style.background = 'linear-gradient(-120deg, #2c3e50, #000000)';
        }
    }

    definirGifEGradiente();

    // Atualizar a cada segundo para acompanhar a mudança de tempo
    setInterval(definirGifEGradiente, 1000);
});
